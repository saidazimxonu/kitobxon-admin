// Kitobxon Admin Panel — server.js
// A minimal Express server that:
//  1. Accepts FCM tokens from the Kitobxon web app and stores them in Firestore.
//  2. Serves a password-protected admin page.
//  3. Sends a push notification (Title + Message) to every saved token via Firebase Admin SDK.

const express = require('express');
const cors = require('cors');
const cookieSession = require('cookie-session');
const path = require('path');
const admin = require('firebase-admin');

// ---------- CONFIG ----------
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET || 'change-this-secret-too';
const PORT = process.env.PORT || 3000;

if (!ADMIN_PASSWORD) {
  console.warn('WARNING: ADMIN_PASSWORD environment variable is not set. Set it before deploying!');
}

// ---------- FIREBASE ADMIN INIT ----------
// Expects the FULL service account JSON (downloaded from Firebase Console)
// to be provided as a single environment variable: FIREBASE_SERVICE_ACCOUNT
let serviceAccount;
try {
  serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT || '{}');
} catch (e) {
  console.error('Failed to parse FIREBASE_SERVICE_ACCOUNT env var as JSON:', e.message);
  serviceAccount = {};
}

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

const db = admin.firestore();
const TOKENS_COLLECTION = 'fcm_tokens';

// ---------- APP SETUP ----------
const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(cookieSession({
  name: 'kitobxon_admin_session',
  secret: SESSION_SECRET,
  maxAge: 24 * 60 * 60 * 1000 // 24 hours
}));

function requireAuth(req, res, next) {
  if (req.session && req.session.loggedIn) {
    return next();
  }
  return res.status(401).json({ ok: false, error: 'Not authenticated' });
}

// ---------- PUBLIC: save a token from the Kitobxon app ----------
app.post('/api/save-token', async (req, res) => {
  try {
    const { token } = req.body || {};
    if (!token || typeof token !== 'string') {
      return res.status(400).json({ ok: false, error: 'Missing token' });
    }
    await db.collection(TOKENS_COLLECTION).doc(token).set({
      token,
      savedAt: admin.firestore.FieldValue.serverTimestamp()
    }, { merge: true });
    res.json({ ok: true });
  } catch (e) {
    console.error('save-token error:', e);
    res.status(500).json({ ok: false, error: 'Server error' });
  }
});

// ---------- LOGIN ----------
app.post('/api/login', (req, res) => {
  const { password } = req.body || {};
  if (!ADMIN_PASSWORD) {
    return res.status(500).json({ ok: false, error: 'Server not configured (ADMIN_PASSWORD missing)' });
  }
  if (password === ADMIN_PASSWORD) {
    req.session.loggedIn = true;
    return res.json({ ok: true });
  }
  return res.status(401).json({ ok: false, error: "Parol noto'g'ri" });
});

app.post('/api/logout', (req, res) => {
  req.session = null;
  res.json({ ok: true });
});

app.get('/api/session', (req, res) => {
  res.json({ loggedIn: !!(req.session && req.session.loggedIn) });
});

// ---------- PROTECTED: token count (nice-to-have, shown in the UI) ----------
app.get('/api/token-count', requireAuth, async (req, res) => {
  try {
    const snap = await db.collection(TOKENS_COLLECTION).count().get();
    res.json({ ok: true, count: snap.data().count });
  } catch (e) {
    console.error('token-count error:', e);
    res.status(500).json({ ok: false, error: 'Server error' });
  }
});

// ---------- PROTECTED: send notification to all saved tokens ----------
app.post('/api/send-notification', requireAuth, async (req, res) => {
  try {
    const { title, message } = req.body || {};
    if (!title || !message) {
      return res.status(400).json({ ok: false, error: 'Sarlavha va xabar matni talab qilinadi' });
    }

    const snapshot = await db.collection(TOKENS_COLLECTION).get();
    const tokens = snapshot.docs.map(doc => doc.id);

    if (tokens.length === 0) {
      return res.json({ ok: true, sent: 0, failed: 0, message: 'Hech qanday saqlangan token topilmadi' });
    }

    // FCM allows max 500 tokens per multicast call — chunk if needed.
    const chunkSize = 500;
    let totalSuccess = 0;
    let totalFailure = 0;
    const invalidTokens = [];

    for (let i = 0; i < tokens.length; i += chunkSize) {
      const chunk = tokens.slice(i, i + chunkSize);
      const response = await admin.messaging().sendEachForMulticast({
        tokens: chunk,
        notification: { title, body: message }
      });
      totalSuccess += response.successCount;
      totalFailure += response.failureCount;

      response.responses.forEach((r, idx) => {
        if (!r.success) {
          const code = r.error && r.error.code;
          if (code === 'messaging/registration-token-not-registered' ||
              code === 'messaging/invalid-argument') {
            invalidTokens.push(chunk[idx]);
          }
        }
      });
    }

    // Clean up invalid/expired tokens so future sends stay efficient.
    if (invalidTokens.length > 0) {
      const batch = db.batch();
      invalidTokens.forEach(t => batch.delete(db.collection(TOKENS_COLLECTION).doc(t)));
      await batch.commit();
    }

    res.json({
      ok: true,
      sent: totalSuccess,
      failed: totalFailure,
      removedInvalid: invalidTokens.length
    });
  } catch (e) {
    console.error('send-notification error:', e);
    res.status(500).json({ ok: false, error: 'Server error: ' + e.message });
  }
});

// ---------- Serve the admin page for any other GET route ----------
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin.html'));
});

app.listen(PORT, () => {
  console.log(`Kitobxon admin panel running on port ${PORT}`);
});
