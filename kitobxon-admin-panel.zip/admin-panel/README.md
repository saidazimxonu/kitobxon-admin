# Kitobxon — Admin Panel

Kitobxon ilovasi foydalanuvchilariga push-xabarnoma (bildirishnoma) yuborish uchun oddiy admin panel.

## Nima uchun kerak?

`kitobxon.html` (asosiy ilova) endi har bir foydalanuvchi push-xabarnomalarga ruxsat berganda o'z **FCM tokenini** shu serverga (`/api/save-token`) yuborib, Firestore'da saqlaydi. Admin panel esa shu saqlangan barcha tokenlarga bir vaqtning o'zida xabar yuborish imkonini beradi.

## 1-qadam: Firebase tomonidan kerakli narsalar

1. **Firestore'ni yoqing** (agar hali yoqilmagan bo'lsa): Firebase Console → Build → Firestore Database → "Create database" → istalgan mintaqa, "Production mode".
2. **Service Account kaliti**: Firebase Console → ⚙️ Project Settings → **Service Accounts** → "Generate new private key" tugmasini bosing. Bu sizga bitta `.json` fayl yuklab beradi — **buni hech kimga bermang, bu maxfiy kalit**.

## 2-qadam: Muhit o'zgaruvchilari (Environment Variables)

Deploy qilishda quyidagi ikkita o'zgaruvchini sozlashingiz kerak (Render/Railway paneli orqali):

| Nomi | Qiymati |
|---|---|
| `ADMIN_PASSWORD` | O'zingiz xohlagan admin paroli (masalan: `MenKitobxonAdminman2026`) |
| `FIREBASE_SERVICE_ACCOUNT` | Yuqorida yuklab olgan `.json` faylning **to'liq matni**, bitta qatorga joylashtirilgan holda (pastda ko'rsatilgan) |
| `SESSION_SECRET` | Ixtiyoriy — istalgan tasodifiy uzun matn (masalan: `a8x9k2m...`) |

**`FIREBASE_SERVICE_ACCOUNT` qanday tayyorlash kerak:**
Yuklab olingan `.json` faylni biror matn muharririda oching, butun matnni nusxalang (boshidan oxirigacha, `{` dan `}` gacha) va shuni **bitta qatorga** joylashtirilgan holda `FIREBASE_SERVICE_ACCOUNT` o'zgaruvchisining qiymati sifatida joylashtiring. Render/Railway kabi platformalar buni katta matn sifatida qabul qiladi, muammo bo'lmaydi.

## 3-qadam: Render'ga joylash (tavsiya etiladi — bepul rejasi bor)

1. [render.com](https://render.com) da akkaunt oching.
2. **New +** → **Web Service**.
3. Ushbu `admin-panel` papkasini GitHub'ga yuklang (yoki Render'ning "Deploy from a Git repo" bo'lmasa, "Public Git repository" orqali ham mumkin).
4. Sozlamalar:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. **Environment** bo'limida yuqoridagi 3 ta o'zgaruvchini qo'shing.
6. **Create Web Service** — bir necha daqiqada tayyor bo'ladi, sizga `https://kitobxon-admin.onrender.com` kabi manzil beriladi.

### Yoki Railway'ga joylash

1. [railway.app](https://railway.app) da akkaunt oching.
2. **New Project** → **Deploy from GitHub repo** (yoki "Empty project" → fayllarni yuklang).
3. **Variables** bo'limida yuqoridagi 3 ta o'zgaruvchini qo'shing.
4. Railway avtomatik `npm install` va `npm start`ni ishga tushiradi.

## 4-qadam: Asosiy ilovani (`kitobxon.html`) shu serverga ulash

Backend manzilingiz tayyor bo'lgach (masalan `https://kitobxon-admin.onrender.com`), shuni menga ayting — men `kitobxon.html` ichidagi kodni yangilab, FCM token olingach uni avtomatik shu serverga yuborib turadigan qilib beraman.

## 5-qadam: Admin panelni ishlatish

1. `https://kitobxon-admin.onrender.com/admin` (yoki asosiy manzilning o'zi) ni oching.
2. `ADMIN_PASSWORD` sifatida bergan parolni kiriting.
3. Sarlavha va xabar matnini yozib, **"📤 Xabar yuborish"** tugmasini bosing — barcha saqlangan qurilmalarga xabar boradi.

## Xavfsizlik eslatmasi

- `FIREBASE_SERVICE_ACCOUNT` va `ADMIN_PASSWORD` — bular **maxfiy**. Hech qachon GitHub'ga ochiq (public) repo sifatida ularni to'g'ridan-to'g'ri kodga yozib qo'ymang — faqat Environment Variables orqali bering.
- Agar GitHub'ga yuklasangiz, `.env` faylini albatta `.gitignore`ga qo'shing.
